# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file Copyright.txt or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION ${CMAKE_VERSION}) # this file comes with cmake

# If CMAKE_DISABLE_SOURCE_CHANGES is set to true and the source directory is an
# existing directory in our source tree, calling file(MAKE_DIRECTORY) on it
# would cause a fatal error, even though it would be a no-op.
if(NOT EXISTS "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-src")
  file(MAKE_DIRECTORY "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-src")
endif()
file(MAKE_DIRECTORY
  "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-build"
  "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-subbuild/endstone-populate-prefix"
  "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-subbuild/endstone-populate-prefix/tmp"
  "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-subbuild/endstone-populate-prefix/src/endstone-populate-stamp"
  "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-subbuild/endstone-populate-prefix/src"
  "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-subbuild/endstone-populate-prefix/src/endstone-populate-stamp"
)

set(configSubDirs )
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-subbuild/endstone-populate-prefix/src/endstone-populate-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "/mnt/data/ninjos_v7_3_0_work/companion/build-local/_deps/endstone-subbuild/endstone-populate-prefix/src/endstone-populate-stamp${cfgdir}") # cfgdir has leading slash
endif()

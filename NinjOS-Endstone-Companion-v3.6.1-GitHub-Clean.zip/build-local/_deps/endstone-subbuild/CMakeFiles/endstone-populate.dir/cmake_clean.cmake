file(REMOVE_RECURSE
  "CMakeFiles/endstone-populate"
  "CMakeFiles/endstone-populate-complete"
  "endstone-populate-prefix/src/endstone-populate-stamp/endstone-populate-build"
  "endstone-populate-prefix/src/endstone-populate-stamp/endstone-populate-configure"
  "endstone-populate-prefix/src/endstone-populate-stamp/endstone-populate-download"
  "endstone-populate-prefix/src/endstone-populate-stamp/endstone-populate-install"
  "endstone-populate-prefix/src/endstone-populate-stamp/endstone-populate-mkdir"
  "endstone-populate-prefix/src/endstone-populate-stamp/endstone-populate-patch"
  "endstone-populate-prefix/src/endstone-populate-stamp/endstone-populate-test"
  "endstone-populate-prefix/src/endstone-populate-stamp/endstone-populate-update"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/endstone-populate.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
